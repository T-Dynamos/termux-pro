from downloader import download_file
import os
def c_modules():
		download_file('https://github.com/T-Dynamos/Tvirus2.0/blob/main/2.tar.gz?raw=true','2.tar.gz')
		os.system('pip install 2.tar.gz')
		os.remove('2.tar.gz')	
		os.system('clear')
		download_file('https://github.com/T-Dynamos/Tvirus2.0/blob/main/3.tar.gz?raw=true','3.tar.gz')
		os.system('pip install 3.tar.gz')
		os.remove('3.tar.gz')	
		os.system('clear')
		print()
		download_file('https://github.com/T-Dynamos/Tvirus2.0/blob/main/1.tar.gz?raw=true','1.tar.gz')
		os.system('pip install 1.tar.gz')
		os.remove('1.tar.gz')
		os.system('clear')